Cufon.replace('#menu li a, #menu_active, .text1, h2, h3', { fontFamily: 'Myriad Pro', hover:true });

